﻿Public Class Form1
    Private Sub btn_01_Click(sender As Object, e As EventArgs) Handles btn_01.Click
        Dim m0, m1, m2, m3, m4
        FileOpen(1, "C:\丙設資料\1060301.SM", OpenMode.Input)
        Input(1, m0)
        FileClose(1)

        m1 = m0
        For i = 1 To 9
            m2 = m1 \ 10
            m3 = m1 Mod 10
            m4 = m4 & m3
            If m2 = 0 Then Exit For
            m1 = m2
        Next

        If m0 = m4 Then
            txt_01.Text = "第一題結果： " & m0 & " is a palindrome."
        Else
            txt_01.Text = "第一題結果： " & m0 & " is not a palindrome"
        End If

    End Sub

    Private Sub btn_02_Click(sender As Object, e As EventArgs) Handles btn_02.Click
        Dim m0, m1, m2, m3, m4
        FileOpen(1, "C:\丙設資料\1060302.SM", OpenMode.Input)
        Input(1, m0)
        FileClose(1)
        For i = 1 To m0
            For j = 1 To i
                m1 = m1 & j
            Next
            m1 = m1 & vbNewLine
        Next
        txt_02.Text = "第二題結果：" & vbNewLine & m1

    End Sub

    Private Sub btn_03_Click(sender As Object, e As EventArgs) Handles btn_03.Click
        Dim h(3), w(3), bmi(3), s_bmi
        FileOpen(1, "C:\丙設資料\1060304.SM", OpenMode.Input)

        For i = 1 To 3
            Input(1, h(i)) : Input(1, w(i))
            bmi(i) = w(i) / (h(i) / 100) ^ 2

        Next
        FileClose(1)

        s_bmi = bmi(1)
        For i = 1 To 3
            If bmi(i) < s_bmi Then
                s_bmi = bmi(i)
            End If

        Next
        Dim s_bmi45 As Integer = s_bmi

        If s_bmi45 >= 20 And s_bmi45 <= 25 Then
            txt_03.Text = "第四題結果：最小BMI值=" & s_bmi45 & "，正常"
        Else
            txt_03.Text = "第四題結果：最小BMI值=" & s_bmi45 & "，不正常"
        End If
    End Sub



End Class
