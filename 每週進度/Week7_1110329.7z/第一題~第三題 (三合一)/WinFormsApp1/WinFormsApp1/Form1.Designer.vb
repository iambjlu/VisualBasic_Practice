﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_01 = New System.Windows.Forms.Button()
        Me.btn_02 = New System.Windows.Forms.Button()
        Me.btn_03 = New System.Windows.Forms.Button()
        Me.txt_01 = New System.Windows.Forms.TextBox()
        Me.txt_02 = New System.Windows.Forms.TextBox()
        Me.txt_03 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_01
        '
        Me.btn_01.Location = New System.Drawing.Point(95, 95)
        Me.btn_01.Name = "btn_01"
        Me.btn_01.Size = New System.Drawing.Size(94, 29)
        Me.btn_01.TabIndex = 0
        Me.btn_01.Text = "第一題"
        Me.btn_01.UseVisualStyleBackColor = True
        '
        'btn_02
        '
        Me.btn_02.Location = New System.Drawing.Point(346, 95)
        Me.btn_02.Name = "btn_02"
        Me.btn_02.Size = New System.Drawing.Size(94, 29)
        Me.btn_02.TabIndex = 0
        Me.btn_02.Text = "第二題"
        Me.btn_02.UseVisualStyleBackColor = True
        '
        'btn_03
        '
        Me.btn_03.Location = New System.Drawing.Point(590, 95)
        Me.btn_03.Name = "btn_03"
        Me.btn_03.Size = New System.Drawing.Size(94, 29)
        Me.btn_03.TabIndex = 0
        Me.btn_03.Text = "第三題"
        Me.btn_03.UseVisualStyleBackColor = True
        '
        'txt_01
        '
        Me.txt_01.Location = New System.Drawing.Point(31, 130)
        Me.txt_01.Multiline = True
        Me.txt_01.Name = "txt_01"
        Me.txt_01.Size = New System.Drawing.Size(236, 229)
        Me.txt_01.TabIndex = 1
        '
        'txt_02
        '
        Me.txt_02.Location = New System.Drawing.Point(273, 130)
        Me.txt_02.Multiline = True
        Me.txt_02.Name = "txt_02"
        Me.txt_02.Size = New System.Drawing.Size(236, 229)
        Me.txt_02.TabIndex = 1
        '
        'txt_03
        '
        Me.txt_03.Location = New System.Drawing.Point(515, 130)
        Me.txt_03.Multiline = True
        Me.txt_03.Name = "txt_03"
        Me.txt_03.Size = New System.Drawing.Size(236, 229)
        Me.txt_03.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 450)
        Me.Controls.Add(Me.txt_03)
        Me.Controls.Add(Me.txt_02)
        Me.Controls.Add(Me.txt_01)
        Me.Controls.Add(Me.btn_03)
        Me.Controls.Add(Me.btn_02)
        Me.Controls.Add(Me.btn_01)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_01 As Button
    Friend WithEvents btn_02 As Button
    Friend WithEvents btn_03 As Button
    Friend WithEvents txt_01 As TextBox
    Friend WithEvents txt_02 As TextBox
    Friend WithEvents txt_03 As TextBox
End Class
