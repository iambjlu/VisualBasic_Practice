﻿Public Class Form1
    Private Sub btn_01_Click(sender As Object, e As EventArgs) Handles btn_01.Click
        Dim m0, m1, m2, m3, m4
        FileOpen(1, "c:\丙設資料\1060301.sm", OpenMode.Input)
        Input(1, m0)
        FileClose(1)

        m1 = m0
        For i = 1 To 9
            m2 = m1 \ 10
            m3 = m1 Mod 10
            m4 = m4 & m3
            If m2 = 0 Then Exit For
            m1 = m2
        Next

        If m0 = m4 Then
            txt_01.Text = "第一題結果:" & m0 & "is a palindrome."
        Else
            txt_01.Text = "第一題結果:" & m0 & "is not a palindrome"
        End If

    End Sub

    Private Sub btn_02_Click(sender As Object, e As EventArgs) Handles btn_02.Click
        Dim m0, m1, m2, m3, m4
        FileOpen(1, "c:\丙設資料\1060302.sm", OpenMode.Input)
        Input(1, m0)
        FileClose(1)
        For i = 1 To m0
            For j = 1 To i
                m1 = m1 & j
            Next
            m1 = m1 & vbNewLine
        Next
        txt_02.Text = "第二題結果:" & vbNewLine & m1

    End Sub

    Private Sub btn_03_Click(sender As Object, e As EventArgs) Handles btn_03.Click
        Dim m0, m1, m2, m3, m4
        FileOpen(1, "c:\丙設資料\1060303.sm", OpenMode.Input)
        Input(1, m0)
        FileClose(1)
        For i = 1 To m0
            If m0 Mod i = 0 Then m1 = m1 + 1
        Next
        If m1 = 2 Then
            txt_03.Text = "第三題結果:" & m0 & "is a prime number."
        Else
            txt_03.Text = "第三題結果:" & m0 & "is not a prime number."
        End If
    End Sub



End Class
